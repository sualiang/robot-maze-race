
## [2026-07-13 08:39] 服务器费用巡查 + 健康检查

### 服务器概览
- **Uptime**: 23 days 9:44, load 0.05/0.04/0.01（极低负载）
- **磁盘**: 99G总量，已用47G（**50%**），可用48G
- **内存**: 3.6G总量，已用1.4G（39%），可用2.2G | Swap已用1.2G/9.9G（12%）
- **连接数**: Threads=6, MaxUsed=21, Total=158,855

### Docker 服务（全部正常 ✅）
| 容器 | 状态 | 端口 |
|------|------|------|
| robotrent-admin | Up 23h (healthy) | 0.0.0.0:8080→80 |
| robotrent-backend | Up 2d (healthy) | 127.0.0.1:3001→3000 |
| robot-maze-race-mysql | Up 8d | 127.0.0.1:3308→3306 |
| robotrent-redis | Up 2w (healthy) | 127.0.0.1:6379→6379 |
| robotrent-mysql | Up 2w (healthy) | 127.0.0.1:3306→3306 |

### 数据库
- **表数量**: 40
- **死锁/外键错误**: LATEST FOREIGN KEY ERROR 存在（需关注）
- **连接数**: 正常

### 端口监听
- 80/443: 正常
- 8080 (admin): 正常
- 3000: 有 node 进程监听（robot-test?）

### discipline-daemon
- **状态**: 未运行（已确认未部署，OK）

### 告警
- ⚠️ **LATEST FOREIGN KEY ERROR** — 数据库最近有外键错误，建议检查

### 结论
- ✅ 磁盘、内存、Docker 服务均正常
- ⚠️ 外键错误需关注，非阻断性问题
