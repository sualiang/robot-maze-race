# 服务器费用巡查记录

## 2026-07-10 20:00 [服务器+审计巡查]

### 服务器健康
- **运行时长**：20天21小时
- **负载**：0.00 / 0.11 / 0.07
- **磁盘**：99G总量，已用45G (48%)
- **内存**：3.6G总量，已用1.5G，可用2.1G
- **Swap**：9.9G，使用1.1G

### Docker服务
| 服务名 | 状态 | 端口 |
|--------|------|------|
| robotrent-backend | Up 3 days (healthy) | 3001 |
| robotrent-admin | Up 9 days (healthy) | 8080 |
| robotrent-mysql | Up 2 weeks (healthy) | 3306 |
| robotrent-redis | Up 2 weeks (healthy) | 6379 |
| robot-maze-race-mysql | Up 6 days | 3308 |

### 数据库
- robotrent 数据库：40张表
- 死锁：无
- 外键错误：有 LATEST FOREIGN KEY ERROR（需关注）

### 端口监听
- 80、443、8080 正常监听

### discipline-daemon
- **状态**：未运行（进程不存在）

### 告警
⚠️ **外键错误**：数据库有 LATEST FOREIGN KEY ERROR，需进一步排查原因
⚠️ **discipline-daemon**：未在运行（可能是旧组件已废弃）

---

## 历史记录

<!-- 追加新的巡查记录在上面 -->
