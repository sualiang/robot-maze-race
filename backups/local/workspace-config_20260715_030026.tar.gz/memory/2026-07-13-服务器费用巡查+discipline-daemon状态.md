# 服务器费用巡查 + discipline-daemon 状态
**巡查时间：** 2026-07-13 20:18 CST
**服务器：** 175.24.200.63
**执行人：** 小D（cron自动任务）
**标记：** [服务器+审计巡查]

---

## 服务器健康

| 指标 | 状态 |
|------|------|
| **Uptime** | 23天21小时，负载 0.05/0.25/0.26（极低） |
| **磁盘** | 99G总/51G用，使用率 **54%** ✅ |
| **内存** | 3.6G总/1.5G用，Swap 9.9G总/1.4G用 ✅ |
| **Docker 容器** | 见下表 |

## Docker 容器状态

| 容器名 | 状态 | 端口 |
|--------|------|------|
| robotrent-admin | ✅ Up 24min (healthy) | 127.0.0.1:8080 |
| robotrent-backend | ✅ Up 4h (healthy) | 127.0.0.1:3001 |
| robotrent-mysql | ✅ Up 2w (healthy) | 127.0.0.1:3306 |
| robotrent-redis | ✅ Up 2w (healthy) | 127.0.0.1:6379 |
| robot-maze-race-mysql | ✅ Up 9d | 127.0.0.1:3308 |
| sasdt-test-redis | ✅ Up 41min (healthy) | 0.0.0.0:6378 |
| sasdt-test-mysql | ✅ Up 41min (healthy) | 0.0.0.0:3307 |
| **sasdt-test-backend** | 🔴 **Restarting (1)** | — |

## 异常项

### 1. sasdt-test-backend 重启循环
- **状态：** `Restarting (1) 59 seconds ago`
- **原因：** 模块找不到 `/app/dist/routes/operator.js`，`requireStack` 指向 `operator.js → index.js → server.js`
- **影响：** 仅 SASDT 测试环境，不影响正式服务
- **建议：** 可能是代码构建问题或 `operator.js` 被误删，需要构建重新部署

### 2. 数据库外键报错（非本系统）
- **来源：** `robot_race.admin_users` 表（robot-maze-race 项目）插入时外键 `fk_admin_users_role` 找不到 `role-super-admin` 这个角色
- **时间：** 2026-06-30，历史遗留问题，非近期
- **影响：** ✅ 不影响 robotrent 主业务

## 端口监听
| 端口 | 状态 |
|------|------|
| 80 (HTTP) | ✅ LISTEN |
| 443 (HTTPS) | ✅ LISTEN |
| 8080 (admin) | ✅ LISTEN |
| 3000 (test) | ✅ LISTEN |

## discipline-daemon
- **状态：** 未运行（确认已移除，OK）

---

## 最终结论

**【正常】正式服务全部健康，无告警。**
- 磁盘 54% ✅
- 内存/CPU 正常 ✅
- Docker 正式服务全部 healthy ✅
- 端口监听正常 ✅

**【注意】测试环境 sasdt-test-backend 重启循环**，非正式环境问题，建议告知相关开发者检查构建。
