# 服务器费用巡查 + 审计报告
**时间**: 2026-07-17 20:00 CST
**服务器**: 175.24.200.63 (cc-dev)

## 系统状态
| 项目 | 状态 |
|------|------|
| 运行时间 | 27 days 21:05 |
| 磁盘使用 | 35G/99G (37%) |
| 内存 | 1.9Gi/3.6Gi (52%) + Swap 1.6Gi/9.9Gi |
| CPU负载 | 0.28 / 0.21 / 0.11 |
| 用户数 | 9 |

## Docker 服务
| 容器 | 状态 | 端口 |
|------|------|------|
| robotrent-admin | Up 3 days (healthy) | 8080 |
| robotrent-backend | Up 3 days (healthy) | 3001 |
| robotrent-mysql | Up 3 weeks (healthy) | 3306 |
| robotrent-redis | Up 3 weeks (healthy) | 6379 |
| robot-maze-race-mysql | Up 13 days | 3308 |
| sasdt-test-backend | Up 3 days | 3002 |
| sasdt-test-redis | Up 3 days (healthy) | 6378 |
| sasdt-test-mysql | Up 3 days (healthy) | 3307 |

**所有容器运行正常**

## 数据库
- robotrent 库：40 张表
- 死锁：无
- 外键错误：有（历史告警，2026-06-30 残留，`fk_admin_users_role` 约束错误，不影响当前运行）

## 端口监听
- 80 (HTTP)、443 (HTTPS) 正常监听
- 8080 (admin)、3000 (已有node) 正常
- 无异常端口

## discipline-daemon
- 状态：未运行（已移除，正常）

## 告警
- ⚠️ **外键错误（历史残留）**: 2026-06-30 在 `robot_race.admin_users` 表上 `fk_admin_users_role` 约束 INSERT 失败，尝试插入不存在的 role_id `role-super-admin`。距今已 17 天，当前无新增。
- ❌ **无其它告警**

## 备注
- 服务器整体健康，费用正常
- sasdt-test 三件套（backend/redis/mysql）运行正常
- robot-maze-race-mysql 运行 13 天稳定
