## API → DB 全量映射审计 (2026-07-16 22:57)

### 审计方法
逐文件检查 47 个 `.ts` 路由的 SQL 表引用 vs 实际表分布：
- Common 库 `robot_maze_race_common`：20 张表
- Operator 库 `op_{id}`：18 张表

### 结论：✅ 全部正确
**0 个未修复的跨库问题。**

之前报告的全部 16 个跨库文件已通过分步查询模式修复：
- `queryOp()` 查 operator 库 → `query()` 回填 common 库数据（users/operators 名称等）

### 已验证文件汇总
| 文件 | 状态 | 修复方式 |
|------|:--:|------|
| admin-dashboard.ts | ✅ | Step1 queryOp + Step2 query |
| admin-finance.ts | ✅ | 分步查询 |
| admin-attendance.ts | ✅ | 分步查询 |
| referees.ts | ✅ | queryOp → query 回填 users/operators |
| player.ts | ✅ | 分步查询 |
| auth.ts | ✅ | 分库分别调 |
| operator.ts | ✅ | finance/export 分步 |
| referee-apply.ts | ✅ | 分步查询 |
| referee-invite.ts | ✅ | 分步查询 |
| venues.ts | ✅ | b14c9cf 修复 |
| race.ts | ✅ | 全部 operator 表 |
| season.ts | ✅ | 无跨库 |
| rank.ts | ✅ | 分步查询 |
| admin-operators.ts | ✅ | 混合用法正确 |
| points-shop.ts | ✅ | 全部 operator 表 |
| operator-marketing.ts | ✅ | executeOp 查 op 表 |
| merchant 系列 | ✅ | 全部 operator 表 |
| wx-pay.ts | ✅ | tx.executeOp 已修 |
