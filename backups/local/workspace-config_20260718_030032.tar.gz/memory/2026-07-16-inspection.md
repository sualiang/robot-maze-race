# 服务器/审计巡查 - 2026-07-16 08:20 CST

[服务器+审计巡查]

## 【服务器费用巡查】

### 系统概览
- **服务器IP**: 175.24.200.63 (cc-dev)
- **运行时间**: 26 days 9:25
- **负载**: 0.00 / 0.04 / 0.08

### 磁盘
- `/dev/vda2`: 99G total, 35G used, 60G free → **37%使用** ✅

### 内存
- **物理内存**: 3.6Gi total, 1.6Gi used, 250Mi free, 2.1Gi buff/cache → 可用约2.0Gi ✅
- **Swap**: 9.9Gi total, 1.6Gi used, 8.4Gi free ✅

### Docker服务
| 服务名 | 状态 | 端口映射 |
|--------|------|---------|
| robotrent-admin | Up 2 days (healthy) | 127.0.0.1:8080→80 |
| robotrent-backend | Up 2 days (healthy) | 127.0.0.1:3001→3000 |
| sasdt-test-backend | Up 2 days | 0.0.0.0:3002→3000 |
| sasdt-test-redis | Up 2 days (healthy) | 0.0.0.0:6378→6379 |
| sasdt-test-mysql | Up 2 days (healthy) | 0.0.0.0:3307→3306 |
| robot-maze-race-mysql | Up 11 days | 127.0.0.1:3308→3306 |
| robotrent-redis | Up 2 weeks (healthy) | 127.0.0.1:6379→6379 |
| robotrent-mysql | Up 2 weeks (healthy) | 127.0.0.1:3306→3306 |

**全部 Docker 服务运行正常** ✅

### 数据库
- **robotrent 数据库**: 40 张表
- **死锁**: 无最新死锁
- **外键错误**: 存在一条历史错误（2026-06-30），来自 `robot_race` 数据库的 `admin_users` 表外键约束失败（role_id 引用的 role 不存在），这是 robot_race 项目的导入问题，非关键业务影响 ⚠️

### 端口监听
| 端口 | 绑定 | 状态 |
|------|------|------|
| 80 (HTTP) | 0.0.0.0 | ✅ |
| 443 (HTTPS) | 0.0.0.0 | ✅ |
| 8080 (Admin) | 127.0.0.1 | ✅ |
| 3000 (Node) | 0.0.0.0 | ✅ |

## 【discipline-daemon】
- **状态**: 未运行/未部署（服务器 ps aux 未找到进程）

## 综合判断
- **费用相关**: 磁盘仅37%，内存充足，无异常资源占用 → 无需扩容 ✅
- **服务健康**: 所有 Docker 服务 healthy/正常运行 ✅
- **告警**: 无严重告警 ⚠️ 注意 `robot_race.admin_users` 存在外键错误（不影响主要业务）
