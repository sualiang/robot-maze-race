## 🔴 多租户跨库 SQL 映射问题 — 全量审计报告 (2026-07-16)

### 架构回顾
- **Common 库**（20表）: users, operators, admin_roles, admin_users, operator_members, operators_registry, referee_invites, seasons, season_user_info, settings, system_config, combat_power, points_transactions, helps, help_helpers, idempotency_keys, notification_logs, client_logs, tasks, user_tasks
- **Operator 库**（18表）: venues, referees, races, race_packages, race_package_coupons, orders, payments, payment_transactions, settlements, marketing_config, checkins, attendance, race_records, race_attendance, ticket_redemptions, merchants, merchant_coupons, user_coupons, entry_deductions, points_exchange_log, operator_sessions

---

### A类：queryOp 里 JOIN/查询 common 库独有的表

| # | 文件 | 行号范围 | 跨库表 | SQL 片段 |
|---|------|---------|--------|---------|
| A1 | admin-dashboard.ts | 83-92 | operators | `FROM operators o LEFT JOIN settlements` |
| A2 | admin-dashboard.ts | 123-129 | operators | `FROM operators o LEFT JOIN settlements` |
| A3 | admin-dashboard.ts | 150-157 | operators | `FROM operators o LEFT JOIN settlements` |
| A4 | admin-dashboard.ts | 179-186 | operators | `FROM operators o LEFT JOIN settlements` |
| A5 | admin-dashboard.ts | 304-321 | operators | `FROM operators o LEFT JOIN settlements` |
| A6 | admin-attendance.ts | 89-93 | users | `LEFT JOIN users u ON u.id = a.user_id` |
| A7 | admin-attendance.ts | 159-162 | users | `LEFT JOIN users u ON u.id = a.user_id` |
| A8 | attendance.ts | 72-74 | users | `LEFT JOIN users u ON u.id = a.user_id` |
| A9 | admin-finance.ts | 40-51 | users | `LEFT JOIN users u ON u.id = s.operator_id` |
| A10 | admin-finance.ts | 103-114 | users | `LEFT JOIN users u ON u.id = s.operator_id` |
| A11 | admin-finance.ts | 216-226 | users | `LEFT JOIN users u ON u.id = s.operator_id` |
| A12 | admin-finance.ts | 270-271 | player_profiles | `LEFT JOIN player_profiles p ON o.user_id = p.user_id` |
| A13 | admin-players.ts | 158 | users | `operator_members WHERE id = ?` |
| A14 | referee-invite.ts | 29-30 | operator_members | `SELECT operator_id FROM operator_members WHERE id = ?` |
| A15 | referee-invite.ts | 104 | operators | `SELECT name FROM operators WHERE id = ?` (queryOpOne context) |

### B类：原生 `?` 占位符（会被 convertSql 误处理）

| # | 文件 | 行号 | SQL 片段 |
|---|------|------|---------|
| B1 | auth.ts | 327 | `FROM operator_members WHERE phone = ?` |
| B2 | auth.ts | 337 | `FROM admin_roles WHERE name = ?` |
| B3 | auth.ts | 346 | `FROM operators WHERE id = ?` |
| B4 | auth.ts | 512 | `FROM operator_members WHERE phone = ?` |
| B5 | auth.ts | 522 | `FROM admin_roles WHERE name = ?` |
| B6 | auth.ts | 531 | `FROM operators WHERE id = ?` |
| B7 | auth.ts | 724 | `WHERE om.id = ?` |
| B8 | auth.ts | 867 | `WHERE m.id = ?` |
| B9 | auth.ts | 1172 | `SELECT id, password FROM operator_members WHERE id = ?` |
| B10 | auth.ts | 1205 | `UPDATE operator_members SET password = ?` |
| B11 | auth.ts | 1248 | `WHERE m.id = ?` |
| B12 | referee-invite.ts | 30 | `FROM operator_members WHERE id = ?` |
| B13 | referee-invite.ts | 104 | `FROM operators WHERE id = ?` |
| B14 | admin-operators.ts | 409 | `WHERE operator_id = ? OR username = $2`（混用） |
| B15 | admin-players.ts | 158 | `FROM operator_members WHERE id = ?` |
| B16 | auth.ts | 603-604 | `FROM referees WHERE phone = $1` → 跨库（referees在op） |

### C类：transaction 回调里调用 tx.queryOp

| # | 文件 | 行号 | 问题 |
|---|------|------|------|
| C1 | admin-operators.ts | 420+ | `tx.queryOp(req, ...)` — tx 对象无此方法 |
| C2 | admin-operators.ts | 425+ | `tx.queryOp(req, ...)` — 同上 |
| C3 | admin-operators.ts | 430+ | `tx.queryOp(req, ...)` — 同上 |

### D类：表和列不存在

| # | 文件 | 行号 | 缺失对象 |
|---|------|------|---------|
| D1 | referee-invite.ts | 55 | `scene_str` 列不存在 |
| D2 | referee-invite.ts | 126-127 | `openid` 列不存在 |
| D3 | client-log.ts | 13,33 | `source` 列不存在 |

---

### 汇总

| 分类 | 数量 | 影响模块 |
|------|:---:|------|
| A类（跨库JOIN） | 15 | Dashboard(5)、考勤(3)、财务(4)、裁判邀请(2)、玩家列表(1) |
| B类（?占位符） | 16 | 登录认证(11)、裁判邀请(2)、运营商(1)、玩家(1)、裁判(1) |
| C类（tx.queryOp） | 3 | 删除运营商 |
| D类（缺列） | 3 | 裁判邀请(2)、客户端日志(1) |
| **总计** | **37** | |

### 核心结论

1. **Dashboard 全崩**：5 处 queryOp 里 JOIN operators，operators 在 common 库，不在 op 库
2. **登录 B 类占位符最多**：auth.ts 有 11 处原生 ?，convertSql 处理后参数错位
3. **考勤/财务**：queryOp 里 JOIN users/player_profiles（这些在 common）
4. **删除运营商**：事务隔离内无 queryOp 方法
5. **裁判功能全崩**：跨库 + 占位符 + 缺列三重叠加
