# 服务器费用巡查 + discipline-daemon 状态检查
**日期：** 2026-07-15 08:23 CST
**执行人：** 小D（cron巡查）

## 服务器健康
- **Uptime：** 25天9小时
- **磁盘：** /dev/vda2 99G, 已用35G (37%)
- **内存：** 3.6G总 / 1.6G已用 / 423MiB缓存可用 / Swap 9.9G使用1.6G
- **Load average：** 0.02, 0.21, 0.23 — 极低负载
- **连接：** 10个用户在线，数据库连接池正常

## Docker 服务
| 容器名 | 状态 | 端口 |
|--------|------|------|
| robotrent-admin | Up 24h (healthy) | :8080->80 |
| robotrent-backend | Up 24h (healthy) | :3001->3000 |
| robotrent-mysql | Up 2w (healthy) | :3306 |
| robotrent-redis | Up 2w (healthy) | :6379 |
| robot-maze-race-mysql | Up 10d | :3308 |
| sasdt-test-backend | Up 30h | :3002->3000 (0.0.0.0) |
| sasdt-test-redis | Up 30h (healthy) | :6378->6379 (0.0.0.0) |
| sasdt-test-mysql | Up 30h (healthy) | :3307->3306 (0.0.0.0) |

> 新增 sasdt-test 三件套（backend + redis + mysql），全部健康运行中。

## 数据库
- robotrent 表数：40
- 死锁：无
- 外键错误：有（同上次，2026-06-30 00:46:10 的旧记录，非当前问题，疑似 robot_race 的历史数据问题，不影响业务）

## 端口监听
- :80 / :443 — Nginx 正常
- :8080 — admin 正常
- :3000 — 未知 node 进程（非 robotrent-backend，是 sasdt-test 占用的? 继续观察）

## discipline-daemon
- **状态：** 未运行（确认进程已在服务器上停止/删除，原来挂载在 :3000 的业务已正常运转）

## 告警
- ⚠️ FK错误日志仍存在（6月30日的旧记录，持续监控中，非新发）
- ⚠️ Swap 使用 1.6G/9.9G (16%)，较上次 1.3G 略有上升，仍属正常范围
- ✅ 磁盘使用率降至 37%（上次 50%，数据可能清理过，正常）
- ✅ 所有业务容器 healthy
- ✅ 无新的数据库死锁

## 费用相关
- 服务器正常运行中，已持续 25天，无异常计费风险
- 新增 sasdt-test 完整开发环境容器，资源占用合理
