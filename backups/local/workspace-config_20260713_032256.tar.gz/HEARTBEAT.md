# Heartbeat Tasks

## 跨 session 上下文同步（重点！）
- 同步范围：**WebChat** ↔ **飞书Bot** ↔ **终端 openclaw CLI** ↔ **Talk 语音**
- 每次心跳检查各 session 最近消息，提取关键上下文（配置变更、决策、新认知）
- 写入 `memory/YYYY-MM-DD.md` 和 `MEMORY.md`
- 用 `sessions_send` 向其他活跃 session 发送简短状态摘要
- 同步频率：每30分钟检查一次

## 上下文健康检查
- 用 `session_status` 检查当前 session 的 tokens 使用率
- 如果超过 100K（约 78% 的 128K 上限），执行 `/reset` 清理上下文
- 记录清理时间和清理前的 token 数到 `memory/YYYY-MM-DD.md`

---

## 2026-07-12 18:43 心跳

### 🟢 服务器状态
- **处理器**：正常运行 22天19小时，负载 0.03/0.05/0.06
- **磁盘**：99G 用 48G（50%），正常
- **内存**：3.6G 总，1.4G 用，687M 空闲，2.2G 可用
- **Swap**：9.9G 用1.3G，正常

### 🟢 Docker 容器状态
| 容器 | 状态 |
|------|------|
| robotrent-admin | 9小时前重启，健康 |
| robotrent-backend | 46小时运行，健康 |
| robotrent-mysql | 2周运行，健康 |
| robotrent-redis | 2周运行，健康 |
| robot-maze-race-mysql | 7天运行 |

### 🟢 本机状态
- **磁盘**：466G 用8.7G，充裕
- **上下文**：33k/131k（25%），健康
- **余额**：¥345.19

### 备注
- 心跳轮询正常，所有服务健康，无需干预。
