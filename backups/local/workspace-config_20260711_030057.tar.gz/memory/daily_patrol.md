# 日常巡检日志

## 2026-07-11 01:55 (周六) — 心跳巡检

### 服务器状态 (175.24.200.63)
| 指标 | 值 | 状态 |
|------|-----|------|
| 系统运行 | 21天3小时 | ✅ |
| CPU Load | 0.07 / 0.04 / 0.02 | ✅ 极低 |
| 内存 | 3.6G total / 1.2G used / 2.4G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.3G used | ✅ 正常 |
| 磁盘 / | 99G / 52G used (55%) | ✅ 良好（较之前明显下降）| 

### 容器状态
| 服务 | 状态 | 运行时间 |
|------|------|---------|
| robotrent-backend | ✅ healthy | 5小时 |
| robotrent-admin | ✅ healthy | 10天 |
| robotrent-redis | ✅ healthy | 2周 |
| robotrent-mysql | ✅ healthy | 2周 |
| robot-maze-race-mysql | ✅ Up | 6天 |

### 服务连通性
| 检查项 | 结果 |
|--------|------|
| MySQL ping | ✅ alive |
| Redis ping | ✅ PONG |
| Backend :3001 | ✅ 404（正常）|
| Admin :8080 | ✅ 200 |
| 端口监听 | ✅ 3306/6379/3001/8080 全部正常 |

**结论：✅ 凌晨心跳巡检通过，一切正常。磁盘使用率从74%降至55%，状态良好。**

---

## 2026-07-10 06:25 (周五) — 心跳巡检

### 服务器状态
| 指标 | 值 | 状态 |
|------|-----|------|
| CPU Load | 0.05 / 0.02 / 0.02 | ✅ 极低 |
| 内存 | 3.6G total / 1.4G used / 2.2G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.1G used | ✅ 正常 |
| 磁盘 / | 99G / 44G used (47%) | ✅ 良好，较之前74%大幅下降 |
| 系统运行 | 20 天 7 小时 | ✅ |

### 容器状态
| 服务 | 状态 | 运行时间 |
|------|------|---------|
| robotrent-mysql | ✅ healthy | 2 周 |
| robotrent-redis | ✅ healthy | 2 周 |
| robotrent-backend | ✅ healthy | 2 天 |
| robotrent-admin | ✅ healthy | 9 天 |
| robot-maze-race-mysql | ✅ Up | 5 天 |

### 端口监听
| 端口 | 服务 | 绑定 |
|------|------|------|
| 80/443 | Nginx | 0.0.0.0 ✅ |
| 3306 | MySQL | 127.0.0.1 ✅ |
| 3308 | race-MySQL | 127.0.0.1 ✅ |
| 6379 | Redis | 127.0.0.1 ✅ |
| 3001 | Backend | 127.0.0.1 ✅ |
| 8080 | Admin | 0.0.0.0 ✅ |

### 数据库
- 死锁/外键错误: 无 ✅

### 今日备份（凌晨3点）
- ✅ MySQL 全部备份成功
- ✅ 配置备份成功
- ✅ 上传文件备份完成
- 磁盘 47%，空间充足

### 结论
✅ **心跳巡检通过** — 所有服务健康，磁盘使用率47%状态良好。
---

## 2026-07-08 15:41 (周三) — 心跳巡检

### 服务器状态
| 指标 | 值 | 状态 |
|------|-----|------|
| CPU Load | 0.68 / 0.68 / 0.37 | ✅ 正常 |
| 内存 | 3.6G total / 1.3G used / 2.3G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.1G used | ✅ 正常 |
| 磁盘 / | 99G / 44G used (47%) | ✅ 大幅下降（之前74%的缓存/备份已被清理）|
| 系统运行 | 18天16小时 | ✅ |

### 容器状态
| 服务 | 状态 | 运行时间 |
|------|------|---------|
| robotrent-mysql | ✅ healthy | 12 天 |
| robotrent-redis | ✅ healthy | 12 天 |
| robotrent-backend | ✅ healthy | 21 小时 |
| robotrent-admin | ✅ healthy | 7 天 |
| robot-maze-race-mysql | ✅ Up | 3 天 |

### 结论
✅ **心跳巡检通过**
- 所有服务正常，磁盘使用率大幅下降至47%（从74%回落，推测为临时/缓存文件被清理）
- 无异常需要关注

---

## 2026-07-08 00:19 (周三) — 心跳巡检

### 服务器状态
| 指标 | 值 | 状态 |
|------|-----|------|
| CPU Load | 0.12 / 0.10 / 0.09 | ✅ 极低 |
| 内存 | 3.6G total / 1.4G used / 2.2G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.1G used | ✅ 正常 |
| 磁盘 / | 99G / 69G used (74%) | ⚠️ 持续偏高 |
| 系统运行 | ✅ | 18天1小时 |

### 容器状态
| 服务 | 状态 | 运行时间 |
|------|------|---------|
| robotrent-mysql | ✅ healthy | 12 天 |
| robotrent-redis | ✅ healthy | 12 天 |
| robotrent-backend | ✅ healthy (up 6h) | 6小时 |
| robotrent-admin | ✅ healthy | 6 天 |
| robot-maze-race-mysql | ✅ Up | 3 天 |

### 服务连通性
| 检查项 | 结果 |
|--------|------|
| SSH 连通 | ✅ 正常 |
| MySQL | ✅ Up 12天 healthy |
| Redis | ✅ Up 12天 healthy |
| Admin | ✅ Up 6天 healthy |
| Backend | ✅ Up 6小时 healthy |

---

## 2026-07-07 22:59 (周二) — 心跳巡检

### 服务器状态
| 指标 | 值 | 状态 |
|------|-----|------|
| CPU Load | 0.02 / 0.05 / 0.08 | ✅ 极低 |
| 内存 | 3.6G total / 1.5G used / 499M free / 2.2G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.0G used | ✅ 正常 |
| 磁盘 / | 99G / 69G used (74%) | ⚠️ 持续偏高 |
| 系统运行 | ✅ | 18天4分钟 |

### 容器状态
| 服务 | 状态 | 运行时间 |
|------|------|---------|
| robotrent-mysql | ✅ healthy | 12 天 |
| robotrent-redis | ✅ healthy | 12 天 |
| robotrent-backend | ✅ healthy (up 4h) | 约4小时 |
| robotrent-admin | ✅ healthy | 6 天 |
| robot-maze-race-mysql | ✅ Up | 3 天 |

### 服务连通性
| 检查项 | 结果 |
|--------|------|
| MySQL ping | ✅ 正常 |
| Redis ping | ✅ PONG |
| Admin port 8080 | ✅ 200 |
| 端口监听 | ✅ 3306/6379/3001/8080 |

### 结论
✅ **心跳巡检通过** — 全部服务正常运行，磁盘74%持续关注。

---

## 2026-07-07 20:52 (周二) — 心跳巡检

### 服务器状态
| 指标 | 值 | 状态 |
|------|-----|------|
| CPU Load | 0.00 / 0.08 / 0.10 | ✅ 极低 |
| 内存 | 3.6G total / 1.4G used / 446M free / 2.2G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.1G used | ✅ 正常 |
| 磁盘 / | 99G / 69G used (74%) | ⚠️ 持续偏高 |
| 系统运行 | ✅ | 17天20小时 |

### 容器状态
| 服务 | 状态 | 运行时间 |
|------|------|---------|
| robotrent-mysql | ✅ healthy | 12 天 |
| robotrent-redis | ✅ healthy | 12 天 |
| robotrent-backend | ✅ healthy (1小时前重启) | 约1小时 |
| robotrent-admin | ✅ healthy | 6 天 |
| robot-maze-race-mysql | ✅ Up | 3 天 |

### 服务连通性
| 检查项 | 结果 |
|--------|------|
| MySQL ping | ✅ 正常 |
| Redis ping | ✅ PONG |
| Admin port 8080 | ✅ 200 |
| 端口监听 | ✅ 3306/6379/3001/8080 全部正常 |

### 备注
- backend 容器刚重启约1小时（18:39巡检时修复），状态 healthy ✅
- 磁盘 74% 持续偏高，关注中
- **结论：✅ 心跳巡检通过，一切正常**

## 2026-07-07 18:39 (周二) — 心跳巡检

### 服务器状态
| 指标 | 值 | 状态 |
|------|-----|------|
| CPU Load | 0.07 / 0.18 / 0.18 | ✅ 极低 |
| 内存 | 3.6G total / 1.3G used / 612M free / 2.3G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.1G used | ✅ 正常 |
| 磁盘 / | 99G / 69G used (74%) | ⚠️ 持续偏高 |
| 系统运行 | ✅ | 17天19小时 |

### 容器状态
| 服务 | 状态 | 运行时间 |
|------|------|---------|
| robotrent-mysql | ✅ healthy | 11 天 |
| robotrent-redis | ✅ healthy | 11 天 |
| robotrent-backend | ✅ healthy (已修复) | 刚刚启动 |
| robotrent-admin | ✅ healthy | 6 天 |
| robot-maze-race-mysql | ✅ Up | 2 天 |

### 服务连通性
| 检查项 | 结果 |
|--------|------|
| MySQL ping | ✅ 正常 |
| Redis ping | ✅ PONG |
| Backend /healthz | ✅ 200 |
| Admin port 8080 | ✅ 200 |

### 🔧 本次修复事项
- **问题**: `robotrent-backend` 容器缺失（docker-compose.yml 和 docker-compose.override.yml 被意外删除，导致 `docker compose up -d` 无法启动 backend）
- **处理**: 从 git HEAD 恢复两个 compose 文件并执行 `docker compose up -d backend`
- **结果**: ✅ backend 容器重新启动并健康运行
- **Host key**: 服务器 ED25519 指纹变更，已更新本地 known_hosts

## 2026-07-07 14:40 (周二) — 心跳巡检

### 服务器状态
| 指标 | 值 | 状态 |
|------|-----|------|
| CPU Load | 0.15 / 0.11 / 0.09 | ✅ 极低 |
| 内存 | 3.6G total / 1.4G used / 666M free / 2.3G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.1G used | ✅ 正常 |
| 磁盘 / | 99G / 69G used (73%) | ⚠️ 持续偏高 |
| 系统运行 | ✅ | 17天15小时 |

### 容器状态
| 服务 | 状态 | 运行时间 |
|------|------|---------|
| robotrent-mysql | ✅ healthy | 11 天 |
| robotrent-redis | ✅ healthy | 11 天 |
| robotrent-backend | ✅ healthy | 7 天 |
| robotrent-admin | ✅ healthy | 6 天 |
| robot-maze-race-mysql | ✅ Up | 2 天 |

### 服务连通性
| 检查项 | 结果 |
|--------|------|
| MySQL ping | ✅ 正常 |
| Redis ping | ✅ PONG |
| 端口 3306(MySQL) | ✅ 127.0.0.1 |
| 端口 6379(Redis) | ✅ 127.0.0.1 |
| 端口 3001(Backend) | ✅ 127.0.0.1 |
| 端口 8080(Admin) | ✅ 0.0.0.0 |

**结论：✅ 心跳巡检通过，磁盘73%持续关注。**

---

## 2026-07-07 11:12 (周二)

### 心跳巡检 — ✅ 一切正常
- 系统运行 17天12小时
- CPU 负载 0.22，极低
- 内存 3.6G总 / 1.2G used / 2.4G avail ✅
- Swap 9.9G总 / 1.2G used ✅
- 磁盘 99G / 69G used (73%) ⚠️ 持续偏高
- Docker: 全部 healthy/Up
  - robotrent-mysql ✅ (11天)
  - robotrent-redis ✅ (11天)
  - robotrent-backend ✅ (7天)
  - robotrent-admin ✅ (6天)
  - robot-maze-race-mysql ✅ (2天)
- MySQL ping ✅
- Redis PONG ✅
- 端口 3306/6379/3001/8080 全部正常监听

**结论：✅ 心跳巡检通过，磁盘73%继续关注。**

---

## 2026-07-07 06:45 (周二)

### 服务器状态
| 指标 | 值 | 状态 |
|------|-----|------|
| CPU Load | 0.04 / 0.05 / 0.01 | ✅ 极低 |
| 内存 | 3.6G total / 1.3G used / 964M free / 2.4G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.2G used | ✅ 正常 |
| 磁盘 / | 99G / 69G used (73%) | ⚠️ 磁盘占用偏高 |

### 容器状态
| 服务 | 状态 | 运行时间 |
|------|------|----------|
| robotrent-mysql | ✅ healthy | 11 天 |
| robotrent-redis | ✅ healthy | 11 天 |
| robotrent-backend | ✅ healthy | 7 天 |
| robotrent-admin | ✅ healthy | 6 天 |
| robot-maze-race-mysql | ✅ Up | 2 天 |

### 端口监听
| 端口 | 服务 | 绑定 |
|------|------|------|
| 3306 | MySQL | 127.0.0.1 ✅ |
| 6379 | Redis | 127.0.0.1 ✅ |
| 3001 | Backend | 127.0.0.1 ✅ |
| 8080 | Admin | 0.0.0.0 ✅ |

### 服务连通性
| 检查项 | 结果 |
|--------|------|
| MySQL ping | ✅ 正常 |
| Redis ping | ✅ PONG |
| Nginx | ✅ 配置通过 |

---

## 2026-07-07 07:54 (周二) — 心跳巡检

### 服务器状态
| 指标 | 值 | 状态 |
|------|-----|------|
| CPU Load | 0.08 / 0.06 / 0.04 | ✅ 极低 |
| 内存 | 3.6G total / 1.2G used / 418M free / 2.4G avail | ✅ 充裕 |
| Swap | 9.9G total / 1.2G used | ✅ 正常 |
| 磁盘 / | 99G / 69G used (73%) | ⚠️ 持续偏高 |
| 系统运行 | ✅ | 17天9小时 |

### 容器状态
| 服务 | 状态 | 运行时间 | 备注 |
|------|------|----------|------|
| robotrent-mysql | ✅ healthy | 11 天 | MySQL 8.0 |
| robotrent-redis | ✅ healthy | 11 天 | |
| robotrent-backend | ✅ healthy | 7 天 | 后端服务 |
| robotrent-admin | ✅ healthy | 6 天 | 管理后台 |
| robot-maze-race-mysql | ✅ Up | 2 天 | 迷宫游戏数据库 |

### 服务连通性
| 检查项 | 结果 |
|--------|------|
| MySQL ping | ✅ 正常 |
| Redis ping | ✅ PONG |
| Nginx | ✅ 配置通过（需sudo验证证书权限） |

### 结论
✅ **心跳巡检通过** — 全部服务正常运行，磁盘73%持续关注中。

---

## 2026-07-06 18:58 (周一)

### 巡检结果
- 系统运行 17天4小时
- CPU 负载 0.06，空闲
- 内存 3.6G总 / 1.2G used / 2.4G avail ✅
- 磁盘 99G / 69G used (73%) ⚠️ 
- Docker: 全部 healthy/Up
  - robotrent-mysql ✅ (10天)
  - robotrent-redis ✅ (10天)
  - robotrent-backend ✅ (6天)
  - robotrent-admin ✅ (6天)
  - robot-maze-race-mysql ✅ (2天)
- MySQL ping ✅
- Redis PONG ✅

**✅ 巡检通过**

---

## 2026-07-06 06:51 (周一)

### 巡检结果
| 检查项 | 状态 | 备注 |
|--------|------|------|
| 系统运行 | ✅ 17天 | |
| CPU Load | ✅ 0.00 — 空闲 | |
| 内存 | ✅ 3.6G总 / 1.2G用 / 2.4G可用 | |
| Swap | ✅ 9.9G总 / 1.2G用 / 8.7G余 | |
| 磁盘 / | ⚠️ 69G/99G (73%) — 持续偏高 | |
| MySQL | ✅ 正常 | |
| Redis | ✅ PONG | |
| Nginx | ✅ 配置语法正确 | |
| 端口 3306(MySQL) | ✅ 127.0.0.1 | |
| 端口 6379(Redis) | ✅ 127.0.0.1 | |
| 端口 3001(Backend) | ✅ 127.0.0.1 | |
| 端口 8080(Admin) | ✅ 0.0.0.0 | |
| 端口 3012 | ✅ 监听中 | |

**所有容器均 healthy/Up，MySQL/Redis 连通正常。**

[巡检通过] ✅ 07:00 心跳巡检 — 一切正常

---

## 2026-07-06 18:58 (周一)

### 巡检结果
- 系统运行 17天4小时
- CPU 负载 0.06，空闲
- 内存 3.6G总 / 1.2G used / 2.4G avail ✅
- 磁盘 99G / 69G used (73%) ⚠️ 
- Docker: 全部 healthy/Up
  - robotrent-mysql ✅ (10天)
  - robotrent-redis ✅ (10天)
  - robotrent-backend ✅ (6天)
  - robotrent-admin ✅ (6天)
  - robot-maze-race-mysql ✅ (2天)
- MySQL ping ✅
- Redis PONG ✅

**✅ 巡检通过**

