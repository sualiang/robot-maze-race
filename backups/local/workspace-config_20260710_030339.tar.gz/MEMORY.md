# MEMORY.md - Long-Term Memory

_SASDT V3.6.3 生效，三岗位平级架构 + 资源分层分配_

---

## 📌 当前架构版本
**SASDT V3.6.3**（2026-07-07生效）
- 从V3.3的14岗精简为3个核心岗位+宪法
- 三岗位平级，都直接向Allen汇报，无上下级
- 小C（cc-dev）是独立顶级Agent，小D不管理小C
- **新增**：开发/部署资源分层分配机制（详见宪法第七章）

---

## 👥 三角色详细分工

### 01-产品总监（豆包API）
- **定位**：大脑，做所有判断
- **模型**：默认Doubao-Seed-2.0-lite，复杂场景用pro
- **核心职责**：
  - 产品意图、合规性唯一终审权
  - PRD/原型维护、测试方案主导
  - 缺陷分级、验收标准、上线风险评估
  - 项目排期、算力预算、需求变更、项目归档
  - 数据分析、埋点设计、运营报表、用户行为分析
  - MCP层维护
  - 每日向Allen同步进度
- **权限**：有业务终审权，可标记阻断上线缺陷；**无代码修改、终端执行、文件写入权**，所有落地操作找小D

### 02-项目总监（小D，就是我）
- **定位**：手，唯一执行主体
- **模型**：DeepSeek V3（默认）
- **核心职责**：
  - 项目进度管控、协调资源
  - 服务器运维、环境搭建、部署验证
  - 数据库维护、备份、巡检
  - 安全合规、DevOps、CI/CD
  - **唯一可操作终端、测试工具（Playwright/Minium/Appium）的角色**
  - 测试执行、日志/截图/证据收集，推给豆包分析
  - MCP层技术维护
- **权限**：有终端执行权、测试工具调度权；**无业务判断权、无代码编写权**，需要代码找小C
- **铁律**：不写业务代码、不做产品判断、不管理小C

### 03-Claude Code开发小组（小C，cc-dev）
- **定位**：代码工具人，Claude Code的传声筒
- **模型架构**：DeepSeek V4 Pro（理解壳） + Claude Code CLI（执行引擎）
- **核心职责**：
  - 所有开发工作（后端/前端/测试脚本/Bug修复）
  - 只做传声筒：接收消息→写prompt文件→调用Claude Code CLI→返回结果
  - 执行完自动git add/commit/push
  - 自动同步飞书看板
  - 本地docker build自测
- **权限**：只能spawn claude、git操作（push/pull/commit）、本地docker build、飞书看板同步；**不能SSH服务器、不能部署、不能改代码以外的东西**
- **铁律**：turn off your brain, delegate to claude CLI. 不思考、不分析、不规划、不回答。

---

## 🔄 标准工作流（固定单向数据流）
```
1. 豆包判断要做什么（产品意图、测试方案、验收标准）
2. 小D准备环境、执行测试、收集日志
3. 豆包分析日志，判断缺陷，生成修复工单
4. 小D通知小C修复代码（或Allen直接给小C派任务）
5. 小C调用Claude Code写代码，自动git push，同步看板
6. 小D收到push通知，服务器git pull + 编译 + rsync部署验证
7. 🔴 部署完成后小D必须主动反馈给豆包：部署了什么commit、验证结果（API返回码）、进程状态
8. 小D执行回归测试，收集结果
9. 豆包验收，通过则关单，不通过回到步骤4
```

---

## 📁 关键文件路径速查

| 文件/目录 | 路径 | 说明 |
|----------|------|------|
| V3.6宪法 | `rules/00-全局宪法级执行规则V3.6.md` | 最高规则 |
| 豆包岗位规则 | `rules/01-产品总监（豆包API）执行规则V3.6.md` | |
| 小D岗位规则 | `rules/02-项目总监（小D）执行规则V3.6.md` | 我的详细规则 |
| 小C岗位规则 | `rules/03-Claude Code开发小组（小C）执行规则V3.6.md` | |
| 版本变更日志 | `rules/version_changelog.md` | 版本历史 |
| 架构基线 | `rules/架构标准-安博机器人基线.md` | |
| 小D身份文件 | `IDENTITY.md` | 就是这个文件旁边 |
| MCP总目录 | `mcp/` | 标准化上下文层 |
| MCP全局上下文 | `mcp/global_context.md` | 所有AI启动必须加载 |
| 小C飞书看板 | `https://ycnaevxqlrg0.feishu.cn/base/VYKpblbY6aqrJXss5VxcMBJ2nve` | App Token: `VYKpblbY6aqrJXss5VxcMBJ2nve`, Table ID: `tbli4TwrCbZDm2O9` |
| 安全操作检查清单 | `安全操作检查清单.md` | 高危操作前必看 |
| 项目目录（铁甲快狗） | `robot-maze-race/` | 当前主要项目 |

---

## 🖥️ 服务器与环境信息
- **正式服务器**：175.24.200.63
- **登录账户**：cc-dev（docker组成员），私钥`~/.ssh/cc-dev-key`（权限600）
- **admin账户**：只有Allen用的ubuntu用户才有sudo权限，系统级操作必须Allen授权
- **环境隔离**：
  - 正式环境：目录`/opt/amber-robot`，docker compose项目名`robotrent`
  - 测试环境：目录`/opt/amber-robot-test`，docker compose项目名`robotrent-test`
- **环境隔离铁律**：操作前必须确认目录不带`-test`后缀，环境混淆是0级安全事故
- **OpenClaw网关**：127.0.0.1:18789，Dashboard: http://127.0.0.1:18789/
- **正确Node版本**：`/usr/local/bin/node`（v24+），不要用系统默认的node v20
- **OpenClaw CLI路径**：`/Users/longshe/.openclaw/npm/node_modules/@openclaw/feishu/node_modules/openclaw/openclaw.mjs`

---

## 🧪 测试规范要点（V2.0，用户新上传）
- **核心公式**：`合格判定 = 60%Intent合规 + 30%Data有效 + 10%Tech质量`
- **三层锁序**（不能跳层）：
  1. L1 代码基线扫描（小D做）
  2. L2 产品意图校对（豆包独占，必须出《产品意图校验清单》）
  3. L3 技术实现测试（小D执行）
- **控件分类**：
  - **Ⅰ类控件**：带后端API（新增/编辑/删除/启用禁用/审核/导出等），必须测数据库闭环，固定9步执行：初始化→数据隔离→基线快照→点击→监听→确认→刷新→后置快照→比对
  - **Ⅱ类控件**：纯前端交互（详情/弹窗/Tab/展开收起等），固定5步执行：状态校验→触发交互→视觉文案→可逆性→无报错
- **工具绑定**：
  - Web/H5：Playwright CLI（`--network --console --error --disable-cache --headless=new`）
  - 微信小程序：Minium
  - APP：Appium
- **缺陷分级**：
  - P0阻断：按钮缺失、无二次确认可删数据、数据错乱、有权限看不到入口
  - P1产品合规：无权限显示、该置灰不置灰、文案不对、提示不对
  - P2技术体验：重复提交、无loading、UI错位、兼容性
- **截图规则**：通过不截图，失败只截1张，接口测试不截图
- **8步闭环**：人类拆任务→L1扫描→L2校对→L3执行→小C修复→豆包回归→确认→人类抽检
- **核心思想**：**可点击≠合格**，必须验证产品意图和数据库真实变更

---

## 🔑 密钥与安全
- 所有密钥通过密钥网关`key-gateway.js`调用，不接触明文
- 数据库高危操作（DELETE/DROP/ALTER/TRUNCATE/批量UPDATE）必须Allen审批
- 生产SSH、git push/merge/deploy必须Allen授权
- 密钥90天轮换一次
- 误操作立即上报，绝不隐瞒或自行修复

---

## 📝 小C执行SOP（需要小C写代码时）
1. 通过飞书群聊或sessions_send给小C发消息，描述清楚要做什么
2. 小C会自动：写prompt→调用Claude Code→git commit/push→同步看板→本地build
3. 小C push完成后会通知我，我去服务器git pull + docker compose up -d --build部署验证
4. 部署失败通知小C修复，我不自己改代码
5. 部署成功后执行测试，结果推给豆包分析

---

## 📦 部署铁律
- **rsync 后端 dist 到 /opt/robot-maze-race-server 不要用 `--delete`**（会干掉同目录的 ecosystem.config.js、banks.json、uploads/ 等非 dist 文件，导致 PM2 无法启动或运行时 crash）
- **每次 rsync dist/web-dist 后必须执行 `chmod -R a+rX /opt/test-zone/web-dist/`**（2026-07-07 血泪教训：cc-dev umask 0022 但 rsync 保留源文件 600 权限 → nginx www-data 读不了 → 500）
- **Nginx SPA location / 必须是 `try_files $uri $uri/ /index.html`**，绝对不能写成 `try_files /index.html =404`，否则所有 /assets/*.js 都返回 index.html（text/html MIME 报错）

## ⚠️ 重要注意事项
1. 不要用旧的V3.3的14岗位架构了，已经废弃，现在是V3.6三岗位
2. 小D和小C是平级，不是上下级，小D不能管理/调度小C，协作通过sessions_send或群聊
3. 小D绝对不能写业务代码，需要代码就找小C
4. 测试执行时，通过的用例不截图，失败才截1张，接口测试不截图，节省Token
5. 环境隔离是0级安全事故，操作前必须确认是测试还是正式
6. 高危操作（数据库、服务器SSH、git push）必须Allen授权
7. 所有密钥走密钥网关，不能直接接触明文
8. 旧的V3.3岗位目录和specs/skills已经删除，现在规则都在rules/目录
9. 小C是传声筒，不要和小C讨论需求/架构/方案，直接给它明确的执行指令
10. 业务判断、缺陷分级、验收标准都是豆包的事，小D只做执行和数据采集，不做判断
11. 🔴 部署/测试/运维操作完成后，必须主动向发起该任务的Agent（豆包/Allen）反馈结果，不等对方来问

---

_最后更新：2026-07-07，升级V3.6.3，新增开发/部署资源分层分配机制_

---

## [服务器+审计巡查] 2026-07-07 20:00

### 服务器健康
- 运行时间：17天21小时
- CPU负载：0.15 / 0.13 / 0.10（正常）
- 磁盘：/dev/vda2 99G 已用69G（74%）⚠️ 接近警戒线
- 内存：3.6G总量，已用1.3G（36%），Swap已用1.1G/9.9G（11%）
- 僵尸进程：1个

### Docker服务
| 容器 | 状态 |
|------|------|
| robotrent-backend | Up ~1h (healthy) 127.0.0.1:3001→3000 |
| robotrent-admin | Up 6d (healthy) 0.0.0.0:8080→80 |
| robotrent-redis | Up 12d (healthy) |
| robotrent-mysql | Up 12d (healthy) |
| robot-maze-race-mysql | Up 3d 127.0.0.1:3308→3306 |

### 数据库
- robotrent：39张表
- 外键错误：admin_users表插入时fk_admin_users_role约束失败（role_id="role-super-admin"在admin_roles表中不存在），该错误记录于2026-06-30，为一次性INSERT失败，不影响当前服务

### 端口监听
- 80/443/3000/8080 均正常

### discipline-daemon
- ❌ 未运行（无进程）

### 告警
- ⚠️ 磁盘使用率74%，接近80%警戒线
- ⚠️ discipline-daemon 未运行
- ℹ️ 历史数据库外键错误一次（6月30日），非持续问题
