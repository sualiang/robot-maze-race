# TOOLS.md - Local Notes

## SSH

- **正式服务器**：`cc-dev@175.24.200.63`，私钥 `~/.ssh/cc_dev_test`（权限 600）
  - docker 组成员，可执行 docker 操作、日常巡检、部署验证
  - 正式环境：`/opt/amber-robot`
  - 测试环境：`/opt/amber-robot-test`
  - admin 级操作需 Allen 授权

## GitHub

- Token: `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`（repo 权限，建仓库用）
- 用户: `sualiang`

- 看板 Bitable App Token: `VYKpblbY6aqrJXss5VxcMBJ2nve`
- 看板表格 ID: `tbli4TwrCbZDm2O9`

## Volcengine

- API Key: `ark-c0751902-4bc9-4646-bc4d-ee738c665aa4-b9247`

## MySQL

- 正式 robotrent：密码 `AmberBot2026!Root`（容器 ENV）
  - 连接：`docker exec robotrent-mysql mysql -uroot -p'密码'`
  - 或 `mysql -h127.0.0.1 -P3306 -uroot -p'密码'`

## Claude Code CLI

- 路径：`~/.npm-global/bin/claude`，v2.1.195
- 调用方式：`claude --permission-mode bypassPermissions --print`
