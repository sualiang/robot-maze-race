
## 2026-07-09 09:36 [服务器+审计巡查]

### 服务器费用巡查
- **磁盘**：47%（44G/99G，剩余51G）
- **内存**：1.3Gi/3.6Gi（36%），Swap 1.2Gi/9.9Gi
- **CPU**：load 0.00/0.03/0.06，空闲
- **Uptime**：19天10小时
- **Docker服务**：
  - robotrent-backend ✅ Up 39h (healthy) → 127.0.0.1:3001
  - robotrent-admin ✅ Up 8d (healthy) → 0.0.0.0:8080
  - robotrent-mysql ✅ Up 13d (healthy) → 127.0.0.1:3306
  - robotrent-redis ✅ Up 13d (healthy) → 127.0.0.1:6379
  - robot-maze-race-mysql ✅ Up 4d → 127.0.0.1:3308
- **数据库**：39表 | 死锁：无 | 外键错误：有（LATEST FOREIGN KEY ERROR，需关注）
- **端口监听**：80/443/3000/8080 正常

### discipline-daemon
- **状态**：已停止（未找到进程）

### 告警
- ⚠️ discipline-daemon 未运行
- ⚠️ 数据库有最新外键错误，需查看详情
