# 铁甲快狗 — 项目概览

> 自动更新于 OpenClaw 每日 MCP 同步提醒
> 最后更新：2026-07-06

---

## 一、开发阶段

| 阶段 | 内容 | 状态 |
|------|------|------|
| Phase 1 | 总部后台 + 运营商后台基础框架 | ✅ 已完成 |
| Phase 2 | 裁判注册全流程（微信OAuth + 邀请链接） | ✅ 代码完成，待 Allen 真机微信测试 |
| Phase 3 | 待定（取决于 Phase 2 验收结果） | ⏳ 规划中 |

---

## 二、当前架构

### 2.1 前端
- 总部后台：`/admin/` — 13800000000（超级管理员）
- 运营商后台：`/operator/` — 各运营商管理员

### 2.2 后端（⚠️ 部署架构冲突）
**服务器上实际运行两个后端项目：**
- `robot-maze-race`（我们的仓库）→ `/opt/robot-maze-race-server`，端口 3010
- `am-b-o-v2`（独立项目）→ 端口 3012

**已知问题：** nginx 将 `/api/v1/auth/me` 流量转向 ambo-v2:3012，导致运营商后台菜单无法加载。等待小D处理部署架构冲突。

### 2.3 数据库
- 主库：`robot_maze_race`
- 新建表：`referee_invites`（Phase 2，裁判邀请链接，24h过期，token唯一索引）
- 扩展字段：`race_packages` 表新增 `growth_value`、`point_value`、`coupon_reward_min_cents`、`coupon_reward_max_cents`

---

## 三、当前阻塞项

| 问题 | 级别 | 描述 | 状态 |
|------|------|------|------|
| Bug #1 运营商后台菜单锁死 | 🔴 紧急 | 13999999999 登录后仅显示个人中心，根因为 nginx 路由冲突 | 待小D修部署架构 |
| Bug #2 参赛包字段控件验证 | 🔵 中 | 被 Bug #1 阻塞，进不去参赛包管理页面 | 暂停 |

---

## 四、Phase 2 裁判注册详情

### 功能模块
- **邀请链接页**（`/referee/invite/:token`）：token 校验 + 运营商信息 + 微信 OAuth + 关注服务号引导
- **注册表单页**（`/referee/register/:token`）：11 字段（含省市区三级联动）+ 校验
- **成功页**：✅ 图标 + 提交说明
- **运营商后台入口**：「邀请裁判」按钮 → 调用 API 生成邀请链接
- **数据库**：`referee_invites` 表

### 测试要求
- 微信 OAuth 部分需 Allen 手机端真机测试
- 邀请链接创建需运营商后台正常 → 当前被 Bug #1 阻塞

---

## 五、多库拆分方案

- 版本：v2.1（已通过产品合规校验，待 Allen 审批 + 小C开发）
- 核心：按运营商拆分运营数据表，主库保留总部级数据
- 看板：https://ycnaevxqlrg0.feishu.cn/base/OurZbwdgvaXBgEsiuxbczCv5nue
- 待补充：裁判注册入口的租户识别、用户换运营商迁移机制
