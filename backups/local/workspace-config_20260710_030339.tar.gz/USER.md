# USER.md - About Your Human

- **Name:** Allen
- **What to call them:** Allen
- **Pronouns:** 
- **Timezone:** Asia/Shanghai (GMT+8)
- **Notes:** 叫我小D，签名"我要指挥AI大军" — 我是他的AI兵 😄

## Context

一路互相认识过来的老铁。喜欢直接、不废话的风格，会切换 DeepSeek 模型省钱/做事。
