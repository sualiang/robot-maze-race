# Heartbeat Tasks

## 跨 session 上下文同步（重点！）
- 同步范围：**WebChat** ↔ **飞书Bot** ↔ **终端 openclaw CLI** ↔ **Talk 语音**
- 每次心跳检查各 session 最近消息，提取关键上下文（配置变更、决策、新认知）
- 写入 `memory/YYYY-MM-DD.md` 和 `MEMORY.md`
- 用 `sessions_send` 向其他活跃 session 发送简短状态摘要
- 同步频率：每30分钟检查一次

## 上下文健康检查
- 用 `session_status` 检查当前 session 的 tokens 使用率
- 如果超过 100K（约 78% 的 128K 上限），执行 `/reset` 清理上下文
- 记录清理时间和清理前的 token 数到 `memory/YYYY-MM-DD.md`
